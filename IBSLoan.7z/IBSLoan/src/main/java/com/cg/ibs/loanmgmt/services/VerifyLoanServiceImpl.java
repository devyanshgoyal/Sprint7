package com.cg.ibs.loanmgmt.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ibs.loanmgmt.models.BankAdmins;
import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.DocumentBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;
import com.cg.ibs.loanmgmt.repositories.BankAdminsDao;
import com.cg.ibs.loanmgmt.repositories.CustomerDao;
import com.cg.ibs.loanmgmt.repositories.DocumentDao;
import com.cg.ibs.loanmgmt.repositories.LoanMasterDao;

@Service
public class VerifyLoanServiceImpl implements VerifyLoanService {
	@Autowired
	private LoanMasterDao loanMasterDao;
	@Autowired
	private BankAdminsDao bankAdminsDao;
	@Autowired
	private ApplyLoanService applyLoanService;
	@Autowired
	private DocumentDao documentDao;
	@Autowired
	private CustomerDao custDao;

	public List<LoanMaster> getSentForVerificationLoans(BankAdmins loggedInBankAdmin) {
		//appointBankAdminIfChanged();
		return loanMasterDao.getSentForVerificationLoans(loggedInBankAdmin);

	}

	private void appointBankAdminIfChanged() {
		boolean check = false;
		List<LoanMaster> allLoans = loanMasterDao.getAllLoans();
		List<BankAdmins> registeredAdmins = bankAdminsDao.getRegisteredBankAdmins();
		List<LoanMaster> toUpdateLoans = new ArrayList<>();
		for (LoanMaster loanMaster : allLoans) {
			check = false;
			for (BankAdmins bankAdmins : registeredAdmins) {
				if (loanMaster.getAdminApprover().equals(bankAdmins)) {
					check = true;
					break;
				}
			}
			if (!check) {
				toUpdateLoans.add(loanMaster);
			}
		}
		applyLoanService.appointBankAdminsToExistingLoans(toUpdateLoans);
	}

	@Override
	@Transactional
	public LoanMaster getLoanByApplicantNum(BigInteger applicantNum) {
		return loanMasterDao.getLoanByApplicantNumber(applicantNum);
	}

	private BigInteger generateLoanNo(LoanMaster globalLoanMaster) {
		StringBuilder sb = new StringBuilder();
		sb.append(LocalDate.now().getYear()).append(LocalDate.now().getMonthValue())
				.append(globalLoanMaster.getApplicationNumber());
		BigInteger loanNumber = new BigInteger(sb.toString());
		return loanNumber;
	}

	@Override
	@Transactional
	public LoanMaster updateLoanPostVerify(LoanMaster globalLoanMaster) {
		globalLoanMaster.setLoanAccountNumber(generateLoanNo(globalLoanMaster));
		return loanMasterDao.updateLoanApprovalDao(globalLoanMaster);
	}

	@Override
	@Transactional
	public LoanMaster updateLoanPostDenial(LoanMaster globalLoanMaster) {
		return loanMasterDao.updateLoanDenialDao(globalLoanMaster);

	}

	@Override
	public void downloadDocument(LoanMaster loanMaster) {
		List<DocumentBean> documents = documentDao.getDocumentByApplicantNum(loanMaster.getApplicationNumber());
		byte[] aadhar = null;
		byte[] loanSpecificDocument = null;
		if (loanMaster.getTypeId().equals(1)) {
			for (DocumentBean documentBean : documents) {
				if (!(documentBean.getAadharCard() == null)) {
					aadhar = documentBean.getAadharCard();
				}
				if (!(documentBean.getProperty_collateral() == null)) {
					loanSpecificDocument = documentBean.getProperty_collateral();
				}
			}
		}
		if (loanMaster.getTypeId().equals(2)) {
			for (DocumentBean documentBean : documents) {
				if (!(documentBean.getAadharCard() == null)) {
					aadhar = documentBean.getAadharCard();
				}
				if (!(documentBean.getAdmissionLetter() == null)) {
					loanSpecificDocument = documentBean.getAdmissionLetter();
				}
			}
		}
		if (loanMaster.getTypeId().equals(3)) {
			for (DocumentBean documentBean : documents) {
				if (!(documentBean.getAadharCard() == null)) {
					aadhar = documentBean.getAadharCard();
				}
				if (!(documentBean.getPanCard() == null)) {
					loanSpecificDocument = documentBean.getPanCard();
				}
			}
		}
		if (loanMaster.getTypeId().equals(4)) {
			for (DocumentBean documentBean : documents) {
				if (!(documentBean.getAadharCard() == null)) {
					aadhar = documentBean.getAadharCard();
				}
				if ((!(documentBean.getVehicleRc() == null))) {
					loanSpecificDocument = documentBean.getVehicleRc();
				}
			}
		}
		File dir = new File("./downloads");
		if (!dir.exists()) {
			dir.mkdir();
		}
		try (FileOutputStream outputStream = new FileOutputStream(
				dir.getPath() + "/" + "Aadhar_" + loanMaster.getApplicationNumber() + ".pdf");
				FileOutputStream outputStream2 = new FileOutputStream(
						dir.getPath() + "/" + "Loan_" + loanMaster.getApplicationNumber() + ".pdf")) {
			outputStream.write(aadhar);
			outputStream2.write(loanSpecificDocument);
			outputStream.flush();
			outputStream2.flush();
			outputStream.close();
			outputStream.close();
		} catch (FileNotFoundException exp) {
			System.out.println(exp.getMessage());
		} catch (IOException exp1) {
			System.out.println(exp1.getMessage());
		}
	}

	@Override
	public CustomerBean getCustomerFromUci(BigInteger uci) {
		return custDao.getCustomerDetailsByUci(uci);
	}

}
