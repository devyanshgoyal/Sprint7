package com.cg.ibs.loanmgmt.services;

import java.math.BigInteger;

import com.cg.ibs.loanmgmt.models.CustomerBean;

public interface CustomerService {
	boolean verifyCustomerLogin(String userId, String password);

	CustomerBean getCustomer(String userId);

	CustomerBean getCustomerDetailsByUci(BigInteger uci);
}
