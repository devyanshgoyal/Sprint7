package com.cg.ibs.loanmgmt.services;

import java.util.List;

import com.cg.ibs.loanmgmt.models.CustomerBean;
import com.cg.ibs.loanmgmt.models.LoanMaster;

public interface ViewHistoryService {

	List<LoanMaster> getAllLoans(CustomerBean loggedInCustomer);

	List<LoanMaster> sortLoans(List<LoanMaster> allLoans, String fieldSort);

}
