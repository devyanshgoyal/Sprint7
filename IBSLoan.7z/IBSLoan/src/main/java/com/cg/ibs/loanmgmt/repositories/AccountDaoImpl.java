package com.cg.ibs.loanmgmt.repositories;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.ibs.loanmgmt.models.Account;
import com.cg.ibs.loanmgmt.models.LoanMaster;

@Repository("AccountDao")
public class AccountDaoImpl implements AccountDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Account getAccount(BigInteger accountNumber) {
		return entityManager.find(Account.class, accountNumber);
	}

	@Override
	public Account addLoanAmount(LoanMaster loanMaster) {
		Account account = new Account();
		loanMaster.getSavingsAccount().setBalance(loanMaster.getLoanAmount());
		return account;
	}

}
